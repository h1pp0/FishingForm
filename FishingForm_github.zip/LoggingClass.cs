﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Fishing
{
    internal static class LoggingClass
    {
        internal static readonly object lockobject;
        public static void WriteFishingStatsToFile(string data)
        {
            var filepath = string.Format("{0}\\FishLog_{1}.txt", Application.StartupPath,
                DateTime.Now.ToShortDateString().Replace('/', '-'));
            try
            {
                lock (lockobject)
                {
                    using (StreamWriter sb = new StreamWriter(filepath, true, Encoding.UTF8))
                    {
                        //TODO Remove
                        //Debug.WriteLine(string.Format("Writing to {0} with data: {1}", filepath, data));
                        sb.WriteLine(data);
                        sb.Flush();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while attempting to write to log file!\n\n" + ex.Message, "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                throw;
            }
        }
    }
}

/*
delegate void StackEventHandler<T, U>(T sender, U eventArgs);

class Stack<T>
{
    public class StackEventArgs : System.EventArgs { }
    public event StackEventHandler<Stack<T>, StackEventArgs> stackEvent;

    protected virtual void OnStackChanged(StackEventArgs a)
    {
        stackEvent(this, a);
    }
}

class SampleClass
{
    public void HandleStackChange<T>(Stack<T> stack, Stack<T>.StackEventArgs args) { }
}

public static void Test()
{
    Stack<double> s = new Stack<double>();
    SampleClass o = new SampleClass();
    s.stackEvent += o.HandleStackChange;
}
 * 
 *     internal class LoggingClass<T>
    {
        public event EventHandler<LoggingClassEventArgs<T>> AddedToFile;
        // or
        // Declare the delegate
        public delegate void LoggingClassToFileDelegate(T data);

        // Create a property for it
        private LoggingClassToFileDelegate Logging_ClassToFileDelegate;
        // Create the event for the delegate
        public event LoggingClassToFileDelegate LoggedToFileCompleted;
        //

        public void WriteFishingStatsToFile(T data)
        {
            var filepath = string.Format("{0}\\FishLog_{1}.txt", Application.StartupPath,
                DateTime.Now.ToShortDateString().Replace('/', '-'));
            try
            {
                using (StreamWriter sb = new StreamWriter(filepath, true, Encoding.UTF8))
                {
                    Debug.WriteLine(string.Format("Writing to {0} with data: {1}", filepath, data));
                    sb.WriteLine(data);
                    sb.Flush();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while attempting to write to log file!\n\n" + ex.Message, "Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                throw;
            }
            finally
            {
                OnAddedToFile(data);
            }
        }

        private void OnAddedToFile(T data)
        {
            if (AddedToFile != null)
            {
                // Execute event to notify that we finished writing to the file
                AddedToFile(this, new LoggingClassEventArgs<T>(data));
            }
        }
    }

    internal class LoggingClassEventArgs<T> : EventArgs
    {
        public T Data { get; set; }

        public LoggingClassEventArgs(T data)
        {
            Data = data;
        }
    }

    internal class GetSomeDataClass
    {
        public IEnumerable<MobDataArray> GetEnemiesInRange(MobDataArray[] moblist)
        {
            foreach (var mob in moblist)
            {
                if (FishingForm._FFACE.NPC.Distance(mob.npcid) < 50d)
                {
                    yield return mob;
                }
            }
        }
    }

    internal class MobDataArray
    {
        public string npcname { get; set; }
        public int npcid { get; set; }

        public MobDataArray(string name, int id)
        {
            npcname = name;
            npcid = id;
        }
    }
*/